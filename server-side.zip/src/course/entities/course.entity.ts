export class Course {}
